<?php
$d=__DIR__.'/collectibles';
if(!is_dir($d))@mkdir($d);
if(isset($_GET['l']))exit(json_encode(array_map('basename',array_reverse(glob("$d/*.jpg")))));
if(isset($_GET['v'])){$f="$d/".basename($_GET['v']);if(is_file($f)){header('Content-Type: image/jpeg');readfile($f);}exit;}
if(isset($_POST['del'])){@unlink("$d/".basename($_POST['del']));exit('ok');}
$b=base64_decode(preg_replace('#^data:image/\w+;base64,#','',$_POST['i']??''));
if($b&&@getimagesizefromstring($b)){file_put_contents("$d/".date('Ymd_His').'.jpg',$b);echo 'ok';}