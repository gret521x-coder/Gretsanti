<?php
// Upload this file as "api.php" inside the htdocs folder of aidekupal.unaux.com
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$dataDir = __DIR__ . '/chatdata';
$uploadDir = __DIR__ . '/uploads';
$logFile = $dataDir . '/chatlog.json';

if (!is_dir($dataDir)) { mkdir($dataDir, 0755, true); }
if (!is_dir($uploadDir)) { mkdir($uploadDir, 0755, true); }

if (!file_exists($logFile)) {
    file_put_contents($logFile, json_encode(['messages' => [], 'reactions' => new stdClass()]));
}

$action = $_GET['action'] ?? '';

// 1. Health check
if ($action === 'ping') {
    echo json_encode(['ok' => true, 'status' => 'Storage Ready']);
    exit;
}

// 2. Load saved chatlogs & reactions
if ($action === 'history') {
    $raw = file_get_contents($logFile);
    $db = json_decode($raw, true);
    if (!$db) {
        $db = ['messages' => [], 'reactions' => new stdClass()];
    }
    echo json_encode([
        'ok' => true,
        'messages' => $db['messages'] ?? [],
        'reactions' => $db['reactions'] ?? new stdClass()
    ]);
    exit;
}

// 3. Save a new message to chatlog.json
if ($action === 'save') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input || empty($input['chatId'])) {
        echo json_encode(['ok' => false, 'error' => 'Invalid payload']);
        exit;
    }

    $fp = fopen($logFile, 'c+');
    if (flock($fp, LOCK_EX)) {
        $raw = stream_get_contents($fp);
        $db = json_decode($raw, true) ?: ['messages' => [], 'reactions' => []];

        // Deduplicate by chatId
        $exists = false;
        foreach ($db['messages'] as $m) {
            if (($m['chatId'] ?? '') === $input['chatId']) {
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            $db['messages'][] = $input;
            // Keep last 500 messages so file stays fast
            if (count($db['messages']) > 500) {
                $db['messages'] = array_slice($db['messages'], -500);
            }
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, json_encode($db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    echo json_encode(['ok' => true]);
    exit;
}

// 4. Save/toggle reaction
if ($action === 'react') {
    $input = json_decode(file_get_contents('php://input'), true);
    $msgId = $input['targetMsgId'] ?? '';
    $emoji = $input['emoji'] ?? '';
    $userId = $input['userId'] ?? '';
    $userName = $input['userName'] ?? '';

    if (!$msgId || !$emoji || !$userId) {
        echo json_encode(['ok' => false]);
        exit;
    }

    $fp = fopen($logFile, 'c+');
    if (flock($fp, LOCK_EX)) {
        $raw = stream_get_contents($fp);
        $db = json_decode($raw, true) ?: ['messages' => [], 'reactions' => []];
        if (!isset($db['reactions']) || !is_array($db['reactions'])) {
            $db['reactions'] = [];
        }

        if (isset($db['reactions'][$msgId][$emoji][$userId])) {
            unset($db['reactions'][$msgId][$emoji][$userId]);
            if (empty($db['reactions'][$msgId][$emoji])) {
                unset($db['reactions'][$msgId][$emoji]);
            }
        } else {
            $db['reactions'][$msgId][$emoji][$userId] = $userName;
        }

        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($db, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        flock($fp, LOCK_UN);
    }
    fclose($fp);

    echo json_encode(['ok' => true]);
    exit;
}

// 5. Upload pictures or files (all users)
if ($action === 'upload') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['ok' => false, 'error' => 'No file uploaded or upload error']);
        exit;
    }

    $file = $_FILES['file'];
    $originalName = basename($file['name']);
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    // Block executable scripts for server safety
    $blocked = ['php', 'phtml', 'php3', 'php4', 'php5', 'exe', 'sh', 'bat', 'cmd', 'js', 'html', 'htm', 'htaccess'];
    if (in_array($ext, $blocked)) {
        echo json_encode(['ok' => false, 'error' => 'File type not allowed for security']);
        exit;
    }

    $safeName = date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . ($ext ? '.' . $ext : '');
    $destPath = $uploadDir . '/' . $safeName;

    if (move_uploaded_file($file['tmp_name'], $destPath)) {
        $imageExts = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'];
        $isImage = in_array($ext, $imageExts);
        echo json_encode([
            'ok' => true,
            'url' => 'uploads/' . $safeName,
            'originalName' => $originalName,
            'isImage' => $isImage
        ]);
    } else {
        echo json_encode(['ok' => false, 'error' => 'Failed to save file on server']);
    }
    exit;
}

// 6. Host clear logs
if ($action === 'clear') {
    file_put_contents($logFile, json_encode(['messages' => [], 'reactions' => new stdClass()]));
    echo json_encode(['ok' => true]);
    exit;
}

echo json_encode(['ok' => false, 'error' => 'Unknown action']);
?>
