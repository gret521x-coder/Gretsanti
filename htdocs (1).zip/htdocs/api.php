<?php
/* =====================================================================
   Black Cat Group Chat — single-file backend (PHP 7+ / Apache shared host)
   Actions: load | gif | send | react | upload | clear
   ===================================================================== */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
error_reporting(0);
ini_set('display_errors', '0');

define('BASE_DIR',   __DIR__);
define('DATA_DIR',   BASE_DIR . '/chatdata');
define('UPLOAD_DIR', BASE_DIR . '/uploads');
define('CHAT_FILE',  DATA_DIR . '/chatlog.json');
define('MAX_HISTORY', 200);
define('MAX_TEXT', 2000);
define('MAX_UPLOAD_BYTES', 8 * 1024 * 1024);

$RX_ALLOWED = array('❤️', '😆', '😮', '😢', '😡', '👍', '🐈‍⬛');
$IMG_EXT = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp');
$DOC_EXT = array('pdf', 'txt', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv',
                 'zip', 'rar', '7z', 'mp3', 'wav', 'ogg', 'm4a', 'mp4', 'webm',
                 'mov', '3gp', 'json', 'md', 'apk', 'ttf', 'otf');

function out($ok, $data = array()) {
    $data['ok'] = $ok;
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ensureDirs() {
    if (!is_dir(DATA_DIR)) { @mkdir(DATA_DIR, 0755, true); }
    if (!is_dir(UPLOAD_DIR)) { @mkdir(UPLOAD_DIR, 0755, true); }
    /* Block script execution inside the writable folders (Apache). */
    $ht = UPLOAD_DIR . '/.htaccess';
    if (is_dir(UPLOAD_DIR) && !file_exists($ht)) {
        @file_put_contents($ht,
            "php_flag engine off\n" .
            "RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .phps .cgi .pl\n" .
            "Options -Indexes\n");
    }
    $htd = DATA_DIR . '/.htaccess';
    if (is_dir(DATA_DIR) && !file_exists($htd)) {
        @file_put_contents($htd,
            "php_flag engine off\n" .
            "RemoveHandler .php .phtml .php3 .php4 .php5 .php7 .phps .cgi .pl\n" .
            "Options -Indexes\n");
    }
}

function loadLog() {
    ensureDirs();
    if (!file_exists(CHAT_FILE)) {
        @file_put_contents(CHAT_FILE, '[]');
    }
    $raw = @file_get_contents(CHAT_FILE);
    $arr = json_decode((string)$raw, true);
    return is_array($arr) ? $arr : array();
}

function saveLog(array $arr) {
    ensureDirs();
    $json = json_encode(array_values($arr), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return @file_put_contents(CHAT_FILE, $json, LOCK_EX) !== false;
}

function readBody() {
    $raw = file_get_contents('php://input');
    if (is_string($raw) && $raw !== '') {
        $j = json_decode($raw, true);
        if (is_array($j)) return $j;
    }
    return is_array($_POST) ? $_POST : array();
}

function cleanStr($v, $max) {
    $v = trim((string)$v);
    if (function_exists('mb_substr')) return mb_substr($v, 0, $max, 'UTF-8');
    return substr($v, 0, $max);
}

function cleanId($v) {
    $v = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$v);
    return substr($v, 0, 40);
}

function randHex($n) {
    try { return bin2hex(random_bytes($n)); } catch (Throwable $e) {}
    if (function_exists('openssl_random_pseudo_bytes')) {
        return bin2hex(openssl_random_pseudo_bytes($n));
    }
    return bin2hex(uniqid('', true)) . str_pad((string)mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
}

/* ================= routing ================= */
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : '');

/* ---- load ---- */
if ($action === 'load') {
    $log = loadLog();
    out(true, array('messages' => $log));
}

/* ---- gif (server-side proxy fallback for GIF search) ---- */
if ($action === 'gif') {
    $q = trim((string)(isset($_GET['q']) ? $_GET['q'] : ''));
    $trend = ($q === '' || strtolower($q) === 'trending');
    $api = $trend
        ? 'https://gifsnap.com/api/v1/gifs/trending?page=1&limit=18'
        : 'https://gifsnap.com/api/v1/gifs/search?q=' . rawurlencode($q) . '&page=1&limit=18';
    $ctx = stream_context_create(array(
        'http' => array(
            'method'  => 'GET',
            'timeout' => 6,
            'header'  => "User-Agent: Mozilla/5.0\r\nAccept: application/json\r\n"
        )
    ));
    $raw = @file_get_contents($api, false, $ctx);
    if ($raw === false) out(false, array('error' => 'gif api unreachable'));
    $j = json_decode($raw, true);
    if (!is_array($j) || !isset($j['data'])) out(false, array('error' => 'bad gif response'));
    $gif = array();
    foreach ($j['data'] as $g) {
        if (!is_array($g) || !isset($g['url'])) continue;
        $gif[] = array(
            'url'        => (string)$g['url'],
            'preview_url' => isset($g['preview_url']) ? (string)$g['preview_url'] : ''
        );
        if (count($gif) >= 18) break;
    }
    out(true, array('gifs' => $gif));
}

if ($method !== 'POST') {
    out(false, array('error' => 'POST required for this action'));
}

/* ---- send ---- */
if ($action === 'send') {
    $b = readBody();
    $id = cleanId(isset($b['id']) ? $b['id'] : '');
    if (strlen($id) < 4) out(false, array('error' => 'missing or invalid id'));

    $log = loadLog();
    foreach ($log as $m) {
        if (isset($m['id']) && $m['id'] === $id) {
            out(true, array('dupe' => true)); // already stored — idempotent
        }
    }

    $type = isset($b['type']) ? (string)$b['type'] : 'text';
    if (!in_array($type, array('text', 'image', 'gif', 'file'), true)) $type = 'text';

    $url = '';
    if ($type !== 'text') {
        $u = trim((string)(isset($b['url']) ? $b['url'] : ''));
        $valid =
            preg_match('#^https?://[^\s]{5,400}$#i', $u) ||
            preg_match('#^uploads/[A-Za-z0-9._-]{3,150}$#', $u);
        if (!$valid) out(false, array('error' => 'invalid url'));
        $url = $u;
    }

    $msg = array(
        'id'        => $id,
        'uid'       => cleanId(isset($b['uid']) ? $b['uid'] : 'anon'),
        'name'      => cleanStr(isset($b['name']) ? $b['name'] : 'Guest', 32),
        'text'      => cleanStr(isset($b['text']) ? $b['text'] : '', MAX_TEXT),
        'type'      => $type,
        'url'       => $url,
        'fname'     => cleanStr(isset($b['fname']) ? $b['fname'] : '', 120),
        'size'      => (int)(isset($b['size']) ? $b['size'] : 0),
        'ts'        => (int)(isset($b['ts']) ? $b['ts'] : round(microtime(true) * 1000)),
        'reactions' => array()
    );
    if ($msg['uid'] === '') $msg['uid'] = 'anon';
    if ($msg['name'] === '') $msg['name'] = 'Guest';

    $log[] = $msg;
    if (count($log) > MAX_HISTORY) {
        $log = array_slice($log, -MAX_HISTORY);
    }
    if (!saveLog($log)) out(false, array('error' => 'could not save message'));
    out(true, array('saved' => true));
}

/* ---- react ---- */
if ($action === 'react') {
    $b = readBody();
    $id = cleanId(isset($b['id']) ? $b['id'] : '');
    $emoji = (string)(isset($b['emoji']) ? $b['emoji'] : '');
    $ruid = cleanId(isset($b['uid']) ? $b['uid'] : '');
    $rname = cleanStr(isset($b['name']) ? $b['name'] : 'Guest', 32);
    if (strlen($id) < 4 || $ruid === '' || !in_array($emoji, $RX_ALLOWED, true)) {
        out(false, array('error' => 'bad react payload'));
    }

    $log = loadLog();
    $found = false;
    $rx = array();
    foreach ($log as $k => $m) {
        if ((isset($m['id']) ? $m['id'] : '') === $id) {
            $found = true;
            $rx = (isset($m['reactions']) && is_array($m['reactions'])) ? $m['reactions'] : array();
            $list = (isset($rx[$emoji]) && is_array($rx[$emoji])) ? $rx[$emoji] : array();
            $outList = array();
            $exists = false;
            foreach ($list as $r) {
                $ru = isset($r['uid']) ? $r['uid'] : '';
                if ($ru === $ruid) { $exists = true; }
                else { $outList[] = array('uid' => $ru, 'name' => isset($r['name']) ? $r['name'] : 'Guest'); }
            }
            if (!$exists) { $outList[] = array('uid' => $ruid, 'name' => $rname); }
            if (count($outList)) { $rx[$emoji] = $outList; } else { unset($rx[$emoji]); }
            $log[$k]['reactions'] = $rx;
            break;
        }
    }
    if (!$found) out(false, array('error' => 'message not found'));
    if (!saveLog($log)) out(false, array('error' => 'could not save reaction'));
    out(true, array('reactions' => $rx));
}

/* ---- upload ---- */
if ($action === 'upload') {
    if (empty($_FILES['file']) || !isset($_FILES['file']['error'])) {
        out(false, array('error' => 'no file received'));
    }
    $f = $_FILES['file'];
    if ((int)$f['error'] !== UPLOAD_ERR_OK) out(false, array('error' => 'upload error'));
    if ((int)$f['size'] <= 0 || (int)$f['size'] > MAX_UPLOAD_BYTES) {
        out(false, array('error' => 'file too large (max 8 MB)'));
    }
    if (!is_uploaded_file($f['tmp_name'])) out(false, array('error' => 'invalid upload'));

    $orig = (string)$f['name'];
    $ext = strtolower((string)pathinfo($orig, PATHINFO_EXTENSION));
    if ($ext === '') out(false, array('error' => 'file has no extension'));

    $kind = '';
    if (in_array($ext, $IMG_EXT, true)) {
        $info = @getimagesize($f['tmp_name']);
        if ($info !== false) $kind = 'image';
    }
    if ($kind === '' && in_array($ext, $DOC_EXT, true)) $kind = 'file';
    if ($kind === '') out(false, array('error' => 'file type not allowed'));

    ensureDirs();
    $newName = randHex(8) . '.' . $ext;
    if (!@move_uploaded_file($f['tmp_name'], UPLOAD_DIR . '/' . $newName)) {
        out(false, array('error' => 'could not save file on server'));
    }
    @chmod(UPLOAD_DIR . '/' . $newName, 0644);
    out(true, array(
        'url'  => 'uploads/' . $newName,
        'type' => $kind,
        'name' => cleanStr($orig, 120),
        'size' => (int)$f['size']
    ));
}

/* ---- clear ---- */
if ($action === 'clear') {
    if (saveLog(array())) out(true, array('cleared' => true));
    out(false, array('error' => 'could not clear chat log'));
}

out(false, array('error' => 'unknown action'));
